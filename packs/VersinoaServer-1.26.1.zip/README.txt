Versinoa server resource pack1.26.1
Java Edition1.21.11. Main1.26.1+ uses font versinoa:skill_tree_v2.
Shared blank canvas and positioned class icons/edges; actual names and branches come from Main's selected tree.
No fixed katana labels/connections in the new canvas. Old accessory silhouettes and legacy font assets are retained.
Apply this single combined ZIP. Update server.properties resource-pack URL and resource-pack-sha1 together.
Bedrock uses Main forms/inventory rather than Java font sprites.
