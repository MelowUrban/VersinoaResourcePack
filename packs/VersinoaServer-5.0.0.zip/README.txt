VersinoaServer1.28.0 / Java1.21.11
Combined stamina/mana bars, continuous cake food, dynamic trees, crafting accessories and gradient star health.
Main1.28 confirms the exact server-pack hash before using versinoa:hud glyphs.
Experience notices keep their own baseline below both resource rows. Bedrock uses the numeric fallback.
The native food mirror fills the seamless cake track; 20 native units represent the managed food percentage.
Use the one final combined ZIP; update server resource-pack URL and SHA1 together.

WEAPON_ART_INTEGRATED_13_FAMILIES_14_ITEM_IDS
The supplied recovered artwork archive is integrated: all 13 original 32x32 RGBA PNG bytes are unchanged.
The stable versinoa:weapons/<family> item_model IDs render flat 2D handheld art in GUI and hand contexts.
Shield and spear use the supplied 2D art too; no custom 3D geometry is claimed. Bow uses its one supplied PNG
throughout drawing; no separate new pulling-stage artwork is included. Native material/use/attack behavior and PDC remain Main-owned.
No vanilla texture/model/item asset is overwritten. See versinoa-weapon-models.json for all exact mappings and PNG hashes.
