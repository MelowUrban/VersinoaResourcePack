VersinoaServer1.27.0 / Java1.21.11
Combined dynamic skill trees, crafting accessory backgrounds, and44gradient-gold star health sprites.
Main1.27 uses health scaling20 to keep10normal health icons; actual server health is unchanged by the visual scale.
Half/full/empty/flashing, hardcore, poison/wither/frozen/absorption variants are included. Vehicle icons remain native.
Use this one combined ZIP and update server resource-pack URL and SHA1 together. Java pack does not replace Bedrock textures.
